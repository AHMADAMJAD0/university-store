import React from 'react';

const PhdPage = () => {
  return <div>Graduation Suits for PhD</div>;
};

export default PhdPage;
